#include "store.hpp"

void store::add(component *component)
{
    addComponent(component);
}

